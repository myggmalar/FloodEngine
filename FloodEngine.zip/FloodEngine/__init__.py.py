# -*- coding: utf-8 -*-
"""
/***************************************************************************
 FloodEngine
                                 A QGIS plugin
 Avancerat översvämnings- och erosionsverktyg
                             -------------------
        begin                : 2025-04-17
        copyright            : (C) 2025 by FloodEngine Team
        email                : floodengine@example.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

def classFactory(iface):
    """Ladda FloodEngine class från fil.
    
    :param iface: QGIS-gränssnitt
    :type iface: QgsInterface
    """
    from .floodengine import FloodEngine
    return FloodEngine(iface)
