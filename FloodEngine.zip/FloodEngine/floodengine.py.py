# -*- coding: utf-8 -*-
"""
/***************************************************************************
 FloodEngine
                                 A QGIS plugin
 Avancerat översvämnings- och erosionsverktyg
                              -------------------
        begin                : 2025-04-17
        copyright            : (C) 2025 by FloodEngine Team
        email                : floodengine@example.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os.path
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .ui_dialog import FloodEngineDialog


class FloodEngine:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Konstruktör.

        :param iface: Ett QGIS-gränssnitt
        :type iface: QgsInterface
        """
        # Spara referens till QGIS-gränssnittet
        self.iface = iface
        # Initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # Initialise translations
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'FloodEngine_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = 'FloodEngine'

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Lägg till ett ikon-baserat verktyg i QGIS GUI.

        :param icon_path: Sökväg till ikonen. Kan vara en resurs-sökväg (:/plugins/foo/bar.png) eller en normal filsystemssökväg.
        :type icon_path: str

        :param text: Text som visas i meny
        :type text: str

        :param callback: Function som anropas när verktyget aktiveras
        :type callback: function

        :param enabled_flag: Flagga om om verktyget ska vara aktiverat default, True som standard
        :type enabled_flag: bool

        :param add_to_menu: Om verktyget ska läggas till i menyn, True som standard
        :type add_to_menu: bool

        :param add_to_toolbar: Om verktyget ska läggas till i verktygsfältet, True som standard
        :type add_to_toolbar: bool

        :param status_tip: Text som visas i statusfältet
        :type status_tip: str

        :param parent: Parent widget för verktyget
        :type parent: QWidget

        :param whats_this: Text för "What's This"
        :type whats_this: str

        :returns: Verktyget som lagts till
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Lägg till verktyg i QGIS verktygsfält
            self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Skapa QGIS GUI-element för pluginet"""
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.add_action(
            icon_path,
            text="FloodEngine",
            callback=self.run,
            parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True

    def unload(self):
        """Ta bort plugin-menyn och ikonen från QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                'FloodEngine',
                action)
            self.iface.removeToolBarIcon(action)

    def run(self):
        """Kör pluginets huvudmetod."""
        # Skapa (eller visa) dialogfönstret om det är första körningen
        if self.first_start:
            self.first_start = False
            self.dlg = FloodEngineDialog(self.iface)
        
        # Visa dialogfönstret
        self.dlg.show()
