# Instruktioner för att konvertera logotypen till icon.png
"""
För att konvertera din FloodEngine-logotyp till icon.png:

1. Spara logotypbilden som du skickade (svartvit med FLOOD ENGINE™)
2. Använd ett bildredigeringsprogram (t.ex. GIMP, Photoshop, eller online-verktyg som Pixlr) 
   för att konvertera bilden till PNG-format
3. Döp om filen till exakt 'icon.png'
4. Placera 'icon.png' i samma mapp som de andra plugin-filerna

Rekommenderad storlek för QGIS-plugin ikoner är minst 64x64 pixlar men inte större än 128x128 pixlar.
"""

# OBS: Detta är inte körbar kod, utan instruktioner för hur du skapar icon.png
# från logotypbilden du skickade.
