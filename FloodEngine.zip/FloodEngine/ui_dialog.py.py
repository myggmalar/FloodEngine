# -*- coding: utf-8 -*-
"""
/***************************************************************************
 FloodEngineDialog
                                 A QGIS plugin
 Avancerat översvämnings- och erosionsverktyg
                             -------------------
        begin                : 2025-04-17
        copyright            : (C) 2025 by FloodEngine Team
        email                : floodengine@example.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import time
import tempfile
import logging
import traceback
import numpy as np
import csv
import math

from PyQt5.QtWidgets import (QDialog, QLabel, QVBoxLayout, QHBoxLayout, QLineEdit, 
                            QPushButton, QCheckBox, QMessageBox, QTabWidget, 
                            QWidget, QSlider, QComboBox, QGroupBox, QRadioButton, 
                            QGridLayout, QButtonGroup, QProgressBar, QSplitter, 
                            QFileDialog, QSpacerItem, QSizePolicy)
from PyQt5.QtGui import QFont, QColor, QPalette, QIcon
from PyQt5.QtCore import Qt, QSize, QVariant

from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature, 
                        QgsGeometry, QgsPointXY, QgsRasterLayer, QgsCoordinateReferenceSystem,
                        QgsVectorFileWriter, QgsSymbol, QgsRendererCategory, 
                        QgsCategorizedSymbolRenderer, QgsRasterBandStats,
                        QgsWkbTypes, QgsFeatureRequest, QgsRasterDataProvider)

from .model_hydraulic import (calculate_flood_area, burn_streams, calculate_erosion, 
                             calculate_flow_vectors, calculate_streamlines, load_bathymetry)


class FloodEngineDialog(QDialog):
    """Dialog för FloodEngine-pluginet"""
    
    def __init__(self, iface):
        """Konstruktör för FloodEngineDialog

        :param iface: QGIS-gränssnitt
        :type iface: QgsInterface
        """
        super().__init__()
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.plugin_dir = os.path.dirname(__file__)
        
        # Sätt titeln för dialogen
        self.setWindowTitle("FloodEngine™ 3.4 – Hydraulikmodell")
        self.setMinimumWidth(600)
        self.setMinimumHeight(700)
        
        # Initiera logg
        self.log_file = os.path.join(tempfile.gettempdir(), f"floodengine_log_{int(time.time())}.txt")
        self.logger = self.setup_logger()
        
        # Inställningar för mörkt läge
        self.dark_mode = False
        
        # Skapa gränssnittet
        self.create_ui()
        
        # Koppla signals/slots
        self.connect_signals()
        
    def setup_logger(self):
        """Skapa och konfigurera loggning"""
        logger = logging.getLogger('FloodEngine')
        logger.setLevel(logging.INFO)
        handler = logging.FileHandler(self.log_file)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger
        
    def create_ui(self):
        """Skapa användargränssnittet för dialogen"""
        main_layout = QVBoxLayout()
        
        # Mode toggle
        mode_layout = QHBoxLayout()
        self.basic_radio = QRadioButton("Basic")
        self.advanced_radio = QRadioButton("Advanced")
        self.basic_radio.setChecked(True)
        mode_group = QButtonGroup()
        mode_group.addButton(self.basic_radio)
        mode_group.addButton(self.advanced_radio)
        
        mode_layout.addWidget(QLabel("<b>Modelläge:</b>"))
        mode_layout.addWidget(self.basic_radio)
        mode_layout.addWidget(self.advanced_radio)
        mode_layout.addStretch()
        
        # Lägg till dark mode toggle
        self.dark_mode_checkbox = QCheckBox("Mörkt läge")
        mode_layout.addWidget(self.dark_mode_checkbox)
        
        main_layout.addLayout(mode_layout)
        
        # Tab widget för Basic och Advanced
        self.tab_widget = QTabWidget()
        
        # Basic tab
        self.basic_tab = QWidget()
        basic_layout = QVBoxLayout()
        
        # DEM input
        dem_group = QGroupBox("Digital höjdmodell (DEM)")
        dem_layout = QVBoxLayout()
        
        self.dem_path = QLineEdit()
        self.dem_btn = QPushButton("Välj DEM")
        dem_layout.addWidget(QLabel("DEM-fil (.tif, .asc):"))
        dem_layout.addWidget(self.dem_path)
        dem_layout.addWidget(self.dem_btn)
        dem_group.setLayout(dem_layout)
        
        # Bathymetri input
        bathy_group = QGroupBox("Bathymetri (valfritt)")
        bathy_layout = QVBoxLayout()
        
        self.bathy_path = QLineEdit()
        self.bathy_btn = QPushButton("Välj bathymetri")
        self.bathy_column = QComboBox()
        self.bathy_column.addItems(["x", "y", "z"])
        
        bathy_layout.addWidget(QLabel("Bathymetri (.csv):"))
        bathy_layout.addWidget(self.bathy_path)
        col_layout = QHBoxLayout()
        col_layout.addWidget(QLabel("Kolumner:"))
        col_layout.addWidget(self.bathy_column)
        bathy_layout.addLayout(col_layout)
        bathy_layout.addWidget(self.bathy_btn)
        bathy_group.setLayout(bathy_layout)
        
        # Vattennivå
        water_group = QGroupBox("Vattennivå")
        water_layout = QVBoxLayout()
        
        self.water_level = QLineEdit()
        self.water_level.setText("10")
        
        water_layout.addWidget(QLabel("Vattennivå (m):"))
        water_layout.addWidget(self.water_level)
        
        # Lägg till slider för vattennivå
        water_level_slider_layout = QHBoxLayout()
        self.water_level_slider = QSlider(Qt.Horizontal)
        self.water_level_slider.setMinimum(0)
        self.water_level_slider.setMaximum(20)
        self.water_level_slider.setValue(10)
        water_level_slider_layout.addWidget(QLabel("0m"))
        water_level_slider_layout.addWidget(self.water_level_slider)
        water_level_slider_layout.addWidget(QLabel("20m"))
        water_layout.addLayout(water_level_slider_layout)
        
        water_group.setLayout(water_layout)
        
        # Lägg till alla grupper till basic tab
        basic_layout.addWidget(dem_group)
        basic_layout.addWidget(bathy_group)
        basic_layout.addWidget(water_group)
        basic_layout.addStretch()
        
        self.basic_tab.setLayout(basic_layout)
        
        # Advanced tab
        self.advanced_tab = QWidget()
        advanced_layout = QVBoxLayout()
        
        # Jordart
        soil_group = QGroupBox("Jordartskarta")
        soil_layout = QVBoxLayout()
        
        self.soil_path = QLineEdit()
        self.soil_btn = QPushButton("Välj jordartskarta")
        
        soil_layout.addWidget(QLabel("Jordartskarta (.shp):"))
        soil_layout.addWidget(self.soil_path)
        soil_layout.addWidget(self.soil_btn)
        soil_group.setLayout(soil_layout)
        
        # Inbränning
        inburn_group = QGroupBox("Inbränning av vattendrag")
        inburn_layout = QVBoxLayout()
        
        self.inburn_checkbox = QCheckBox("Aktivera inbränning")
        self.stream_path = QLineEdit()
        self.stream_btn = QPushButton("Välj vattendrag")
        
        inburn_depth_layout = QHBoxLayout()
        self.inburn_depth_label = QLabel("Inbränningsdjup (m): 5")
        self.inburn_depth_slider = QSlider(Qt.Horizontal)
        self.inburn_depth_slider.setMinimum(1)
        self.inburn_depth_slider.setMaximum(20)
        self.inburn_depth_slider.setValue(5)
        self.inburn_depth_input = QLineEdit("5")
        self.inburn_depth_input.setMaximumWidth(50)
        
        inburn_depth_layout.addWidget(self.inburn_depth_label)
        inburn_depth_layout.addWidget(self.inburn_depth_slider)
        inburn_depth_layout.addWidget(self.inburn_depth_input)
        
        inburn_layout.addWidget(self.inburn_checkbox)
        inburn_layout.addWidget(QLabel("Vattendrag (.shp):"))
        inburn_layout.addWidget(self.stream_path)
        inburn_layout.addWidget(self.stream_btn)
        inburn_layout.addLayout(inburn_depth_layout)
        inburn_group.setLayout(inburn_layout)
        
        # Output options
        output_group = QGroupBox("Utdatainställningar")
        output_layout = QVBoxLayout()
        
        self.erosion_checkbox = QCheckBox("Beräkna erosion")
        self.flow_checkbox = QCheckBox("Visa flödespilar")
        self.streamline_checkbox = QCheckBox("Visa streamlines")
        self.log_checkbox = QCheckBox("Skapa loggfil")
        
        output_layout.addWidget(self.erosion_checkbox)
        output_layout.addWidget(self.flow_checkbox)
        output_layout.addWidget(self.streamline_checkbox)
        output_layout.addWidget(self.log_checkbox)
        output_group.setLayout(output_layout)
        
        # Lägg till alla grupper till advanced tab
        advanced_layout.addWidget(soil_group)
        advanced_layout.addWidget(inburn_group)
        advanced_layout.addWidget(output_group)
        advanced_layout.addStretch()
        
        self.advanced_tab.setLayout(advanced_layout)
        
        # Lägg till tabs till tabwidget
        self.tab_widget.addTab(self.basic_tab, "Basic")
        self.tab_widget.addTab(self.advanced_tab, "Advanced")
        
        # Add tab widget to main layout
        main_layout.addWidget(self.tab_widget)
        
        # Run button and progress bar
        bottom_layout = QVBoxLayout()
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        
        self.run_button = QPushButton("Kör modell")
        self.run_button.setFont(QFont("Arial", 12, QFont.Bold))
        self.run_button.setMinimumHeight(40)
        
        bottom_layout.addWidget(self.progress_bar)
        bottom_layout.addWidget(self.run_button)
        
        main_layout.addLayout(bottom_layout)
        
        # Set layout
        self.setLayout(main_layout)
        
        # Uppdatera titelfont
        font = QFont("Arial", 12, QFont.Bold)
        self.setFont(font)
        
    def connect_signals(self):
        """Koppla signaler och slots för UI-interaktioner"""
        # File selection
        self.dem_btn.clicked.connect(lambda: self.select_file(self.dem_path, "Rasterfiler (*.tif *.asc)"))
        self.bathy_btn.clicked.connect(lambda: self.select_file(self.bathy_path, "CSV-filer (*.csv)"))
        self.soil_btn.clicked.connect(lambda: self.select_file(self.soil_path, "Shape-filer (*.shp)"))
        self.stream_btn.clicked.connect(lambda: self.select_file(self.stream_path, "Shape-filer (*.shp)"))
        
        # Mode toggle
        self.basic_radio.toggled.connect(self.toggle_mode)
        self.advanced_radio.toggled.connect(self.toggle_mode)
        
        # Inbränningsdjup
        self.inburn_depth_slider.valueChanged.connect(self.update_inburn_depth)
        self.inburn_depth_input.textChanged.connect(self.update_inburn_slider)
        
        # Vattennivå slider
        self.water_level_slider.valueChanged.connect(self.update_water_level)
        self.water_level.textChanged.connect(self.update_water_slider)
        
        # Run button
        self.run_button.clicked.connect(self.run_model)
        
        # Dark mode toggle
        self.dark_mode_checkbox.toggled.connect(self.toggle_dark_mode)
        
    def select_file(self, target, file_filter):
        """Öppna filväljare för att välja en fil
        
        :param target: QLineEdit där filsökvägen ska sättas
        :type target: QLineEdit
        
        :param file_filter: Filter för filväljaren
        :type file_filter: str
        """
        path, _ = QFileDialog.getOpenFileName(self, "Välj fil", "", file_filter)
        if path:
            target.setText(path)
            
    def toggle_mode(self):
        """Växla mellan Basic och Advanced läge"""
        if self.basic_radio.isChecked():
            self.tab_widget.setCurrentIndex(0)
        else:
            self.tab_widget.setCurrentIndex(1)
            
    def update_inburn_depth(self, value):
        """Uppdatera inbränningsdjup från slider
        
        :param value: Värde från slider
        :type value: int
        """
        self.inburn_depth_label.setText(f"Inbränningsdjup (m): {value}")
        self.inburn_depth_input.setText(str(value))
        
    def update_inburn_slider(self):
        """Uppdatera inbränningsslider från textinput"""
        try:
            value = int(self.inburn_depth_input.text())
            if 1 <= value <= 20:
                self.inburn_depth_slider.setValue(value)
        except ValueError:
            pass
            
    def update_water_level(self, value):
        """Uppdatera vattennivå från slider
        
        :param value: Värde från slider
        :type value: int
        """
        self.water_level.setText(str(value))
        
    def update_water_slider(self):
        """Uppdatera vattennivåslider från textinput"""
        try:
            value = int(float(self.water_level.text()))
            if 0 <= value <= 20:
                self.water_level_slider.setValue(value)
        except ValueError:
            pass
            
    def toggle_dark_mode(self, checked):
        """Växla mellan ljust och mörkt tema
        
        :param checked: Om mörkläge är aktivt
        :type checked: bool
        """
        self.dark_mode = checked
        if checked:
            # Mörkt tema
            self.setStyleSheet("""
                QDialog, QTabWidget, QWidget {
                    background-color: #333333;
                    color: #FFFFFF;
                }
                QGroupBox, QLabel {
                    color: #FFFFFF;
                }
                QPushButton {
                    background-color: #555555;
                    color: #FFFFFF;
                    border: 1px solid #777777;
                    padding: 5px;
                }
                QPushButton:hover {
                    background-color: #666666;
                }
                QLineEdit, QComboBox {
                    background-color: #444444;
                    color: #FFFFFF;
                    border: 1px solid #777777;
                    padding: 3px;
                }
                QCheckBox, QRadioButton {
                    color: #FFFFFF;
                }
            """)
        else:
            # Ljust tema (återställ)
            self.setStyleSheet("")
            
    def validate_inputs(self):
        """Validera alla indata innan modellen körs
        
        :returns: Om valideringen lyckades
        :rtype: bool
        """
        if not self.dem_path.text():
            QMessageBox.warning(self, "Saknar indata", "Du måste ange en DEM-fil!")
            return False
            
        try:
            water_level = float(self.water_level.text())
            if water_level <= 0 or water_level > 100:
                QMessageBox.warning(self, "Ogiltig vattennivå", "Vattennivån måste vara mellan 0 och 100 meter!")
                return False
        except ValueError:
            QMessageBox.warning(self, "Ogiltig vattennivå", "Vattennivån måste vara ett numeriskt värde!")
            return False
            
        # Kontrollera inbränning
        if self.inburn_checkbox.isChecked() and not self.stream_path.text():
            QMessageBox.warning(self, "Saknar indata", "Du har aktiverat inbränning men inte angett något vattendragslager!")
            return False
            
        # Kontrollera erosion
        if self.erosion_checkbox.isChecked() and not self.soil_path.text():
            QMessageBox.warning(self, "Saknar indata", "Du har aktiverat erosionsberäkning men inte angett något jordartslager!")
            return False
            
        return True
    
    def run_model(self):
        """Kör den hydrauliska modellen"""
        if not self.validate_inputs():
            return
            
        # Aktivera progressbar
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        
        # Läs indata
        try:
            dem_path = self.dem_path.text()
            water_level = float(self.water_level.text())
            
            # Loggning
            self.logger.info(f"Kör modell med: DEM={dem_path}, Vattennivå={water_level}")
            
            # Skapa output-mapp om den inte finns
            output_folder = os.path.join(os.path.dirname(dem_path), f"floodengine_output_{int(time.time())}")
            if not os.path.exists(output_folder):
                os.makedirs(output_folder)
                
            output_name = f"oversvamning_{water_level}m"
            output_path = os.path.join(output_folder, output_name + ".shp")
            
            # Kolla om bathymetri används
            bathymetry = None
            if self.bathy_path.text():
                self.progress_bar.setValue(10)
                self.logger.info(f"Laddar bathymetri från {self.bathy_path.text()}")
                bathymetry = load_bathymetry(self.bathy_path.text())
                
            # Kör inbränning om aktiverat
            burned_dem = dem_path
            if self.inburn_checkbox.isChecked() and self.stream_path.text():
                self.progress_bar.setValue(20)
                self.logger.info(f"Utför inbränning med {self.stream_path.text()}")
                depth = int(self.inburn_depth_input.text())
                burned_dem = burn_streams(dem_path, self.stream_path.text(), depth, output_folder)
                
            # Beräkna översvämning
            self.progress_bar.setValue(30)
            self.logger.info(f"Beräknar översvämningsyta med vattennivå {water_level}m")
            flood_layer = calculate_flood_area(self.iface, burned_dem, water_level, bathymetry, output_folder)
            
            # Samla resultatlag för meddelande
            result_layers = [f"- Översvämningslager: {output_name}.shp"]
            
            # Beräkna erosion om aktiverat
            if self.erosion_checkbox.isChecked() and self.soil_path.text():
                self.progress_bar.setValue(60)
                self.logger.info(f"Beräknar erosionsrisk med {self.soil_path.text()}")
                erosion_layer = calculate_erosion(self.iface, burned_dem, flood_layer, self.soil_path.text(), output_folder)
                result_layers.append(f"- Erosionslager: erosionsrisk.shp")
                
            # Skapa flödespilar om aktiverat
            if self.flow_checkbox.isChecked():
                self.progress_bar.setValue(80)
                self.logger.info("Beräknar flödesvektorer")
                flow_layer = calculate_flow_vectors(self.iface, burned_dem, flood_layer, output_folder)
                result_layers.append(f"- Flödespilar: flödespilar.shp")
                
            # Skapa streamlines om aktiverat
            if self.streamline_checkbox.isChecked():
                self.progress_bar.setValue(90)
                self.logger.info("Beräknar streamlines")
                streamline_layer = calculate_streamlines(self.iface, burned_dem, flood_layer, output_folder)
                result_layers.append(f"- Streamlines: streamlines.shp")
                
            # Spara logg om aktiverat
            if self.log_checkbox.isChecked():
                log_output = os.path.join(output_folder, output_name + "_log.txt")
                with open(self.log_file, 'r') as src, open(log_output, 'w') as dst:
                    dst.write(src.read())
                result_layers.append(f"- Loggfil: {output_name}_log.txt")
                    
            self.progress_bar.setValue(100)
            
            # Visa meddelande om slutfört
            QMessageBox.information(self, "Modellkörning slutförd", 
                                     f"Modellen har körts och genererat följande filer i:\n{output_folder}\n\n" + "\n".join(result_layers))
            
            # Zooma till resultat
            if flood_layer:
                self.canvas.setExtent(flood_layer.extent())
                self.canvas.refresh()
            
        except Exception as e:
            self.logger.error(f"Fel vid modellkörning: {str(e)}")
            self.logger.error(traceback.format_exc())
            QMessageBox.critical(self, "Fel vid modellkörning", f"Ett fel inträffade: {str(e)}")
        finally:
            self.progress_bar.setVisible(False)
