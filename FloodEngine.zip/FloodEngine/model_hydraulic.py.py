# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Hydraulic model implementations for FloodEngine
                              -------------------
        begin                : 2025-04-17
        copyright            : (C) 2025 by FloodEngine Team
        email                : floodengine@example.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import time
import tempfile
import numpy as np
import csv
import math
from osgeo import gdal, ogr

from qgis.core import (QgsProject, QgsVectorLayer, QgsRasterLayer, QgsField, 
                        QgsFeature, QgsGeometry, QgsPointXY, QgsWkbTypes, 
                        QgsFeatureRequest, QgsVectorFileWriter, QgsCoordinateReferenceSystem)
from qgis.PyQt.QtCore import QVariant

def load_bathymetry(csv_path):
    """Ladda bathymetridata från CSV
    
    :param csv_path: Sökväg till CSV-fil med bathymetridata
    :type csv_path: str
    
    :returns: Lista med bathymetripunkter (x, y, z)
    :rtype: list
    """
    try:
        points = []
        with open(csv_path, 'r') as f:
            reader = csv.reader(f)
            header = next(reader)  # Skip header
            
            # Identifiera kolumner
            x_col, y_col, z_col = 0, 1, 2  # Default
            
            for i, col in enumerate(header):
                if col.lower() == 'x':
                    x_col = i
                elif col.lower() == 'y':
                    y_col = i
                elif col.lower() == 'z' or col.lower() == 'depth':
                    z_col = i
            
            for row in reader:
                try:
                    x = float(row[x_col])
                    y = float(row[y_col])
                    z = float(row[z_col])
                    points.append((x, y, z))
                except (ValueError, IndexError):
                    continue
                    
        return points
    except Exception as e:
        raise Exception(f"Fel vid inläsning av bathymetri: {str(e)}")

def burn_streams(dem_path, stream_path, depth, output_folder):
    """Bränn in vattendrag i DEM
    
    :param dem_path: Sökväg till DEM-raster
    :type dem_path: str
    
    :param stream_path: Sökväg till vattendragslager (.shp)
    :type stream_path: str
    
    :param depth: Inbränningsdjup i meter
    :type depth: int
    
    :param output_folder: Mapp för utdata
    :type output_folder: str
    
    :returns: Sökväg till inbränd DEM
    :rtype: str
    """
    try:
        # Skapa output-sökväg
        output_dem = os.path.join(output_folder, f"burned_dem.tif")
        
        # Öppna DEM och vattendrag
        dem_ds = gdal.Open(dem_path)
        if not dem_ds:
            raise Exception("Kunde inte öppna DEM-fil")
            
        stream_ds = ogr.Open(stream_path)
        if not stream_ds:
            raise Exception("Kunde inte öppna vattendrag-fil")
        
        # Hämta information om DEM
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        band = dem_ds.GetRasterBand(1)
        no_data = band.GetNoDataValue()
        if no_data is None:
            no_data = -9999
        
        # Läs DEM som numpy-array
        dem_array = band.ReadAsArray()
        
        # Skapa kopia för modifiering
        burned_array = np.copy(dem_array)
        
        # Hämta vattendragslager
        stream_layer = stream_ds.GetLayer()
        
        # Rasterisera vattendrag till en temporär mask
        burn_value = 1
        mask_ds = gdal.GetDriverByName('MEM').Create('', dem_ds.RasterXSize, dem_ds.RasterYSize, 1, gdal.GDT_Byte)
        mask_ds.SetGeoTransform(geotransform)
        mask_ds.SetProjection(projection)
        mask_band = mask_ds.GetRasterBand(1)
        mask_band.Fill(0)
        
        # Rasterisera vattendragen till masken
        gdal.RasterizeLayer(mask_ds, [1], stream_layer, burn_values=[burn_value])
        
        # Läs masken
        mask_array = mask_band.ReadAsArray()
        
        # Sänk höjden på DEM där vattendrag finns
        burned_array = np.where(mask_array == burn_value, burned_array - depth, burned_array)
        
        # Skapa output raster
        driver = gdal.GetDriverByName('GTiff')
        burned_ds = driver.Create(output_dem, dem_ds.RasterXSize, dem_ds.RasterYSize, 1, band.DataType)
        burned_ds.SetGeoTransform(geotransform)
        burned_ds.SetProjection(projection)
        
        # Skriv data
        burned_band = burned_ds.GetRasterBand(1)
        burned_band.WriteArray(burned_array)
        burned_band.SetNoDataValue(no_data)
        
        # Stäng datasets
        dem_ds = None
        stream_ds = None
        mask_ds = None
        burned_ds = None
        
        return output_dem
        
    except Exception as e:
        raise Exception(f"Fel vid inbränning av vattendrag: {str(e)}")

def calculate_flood_area(iface, dem_path, water_level, bathymetry, output_folder):
    """Beräkna översvämningsyta från DEM och vattennivå
    
    :param iface: QGIS-gränssnitt
    :type iface: QgsInterface
    
    :param dem_path: Sökväg till DEM-raster
    :type dem_path: str
    
    :param water_level: Vattennivå i meter
    :type water_level: float
    
    :param bathymetry: Lista med bathymetripunkter (kan vara None)
    :type bathymetry: list
    
    :param output_folder: Mapp för utdata
    :type output_folder: str
    
    :returns: Översvämningslager
    :rtype: QgsVectorLayer
    """
    try:
        # Skapa output sökväg
        output_path = os.path.join(output_folder, f"oversvamning_{water_level}m.shp")
        
        # Öppna DEM
        dem_ds = gdal.Open(dem_path)
        if not dem_ds:
            raise Exception("Kunde inte öppna DEM-fil")
            
        # Hämta information om DEM
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        band = dem_ds.GetRasterBand(1)
        
        # Läs DEM som numpy-array
        dem_array = band.ReadAsArray()
        
        # Applicera bathymetri om tillgänglig
        if bathymetry:
            # Konvertera bathymetripunkter till rasterceller
            for x, y, z in bathymetry:
                # Konvertera koordinater till pixelindex
                pixel_x = int((x - geotransform[0]) / geotransform[1])
                pixel_y = int((y - geotransform[3]) / geotransform[5])
                
                # Kontrollera om inom rasterområdet
                if (0 <= pixel_x < dem_array.shape[1] and 
                    0 <= pixel_y < dem_array.shape[0]):
                    # Uppdatera DEM med bathymetrivärdet
                    dem_array[pixel_y, pixel_x] = z
        
        # Skapa binär översvämningskarta (1 där höjd <= vattennivå, 0 annars)
        flood_array = np.where(dem_array <= water_level, 1, 0)
        
        # Skapa temporär binär raster
        temp_flood_raster = os.path.join(output_folder, "temp_flood.tif")
        driver = gdal.GetDriverByName('GTiff')
        flood_ds = driver.Create(temp_flood_raster, dem_ds.RasterXSize, dem_ds.RasterYSize, 1, gdal.GDT_Byte)
        flood_ds.SetGeoTransform(geotransform)
        flood_ds.SetProjection(projection)
        flood_band = flood_ds.GetRasterBand(1)
        flood_band.WriteArray(flood_array)
        flood_band.SetNoDataValue(0)
        flood_ds = None
        
        # Konvertera raster till polygoner
        flood_depth_raster = os.path.join(output_folder, "flood_depth.tif")
        depth_ds = driver.Create(flood_depth_raster, dem_ds.RasterXSize, dem_ds.RasterYSize, 1, gdal.GDT_Float32)
        depth_ds.SetGeoTransform(geotransform)
        depth_ds.SetProjection(projection)
        depth_band = depth_ds.GetRasterBand(1)
        
        # Beräkna vattendjup för översvämningsområden
        depth_array = np.where(flood_array == 1, water_level - dem_array, 0)
        depth_band.WriteArray(depth_array)
        depth_band.SetNoDataValue(0)
        depth_ds = None
        
        # Konvertera raster till polygoner med GDAL
        flood_ds = gdal.Open(temp_flood_raster)
        flood_band = flood_ds.GetRasterBand(1)
        
        # Skapa shapefil
        driver = ogr.GetDriverByName("ESRI Shapefile")
        if os.path.exists(output_path):
            driver.DeleteDataSource(output_path)
            
        out_ds = driver.CreateDataSource(output_path)
        out_layer = out_ds.CreateLayer("flood", None, ogr.wkbPolygon)
        
        # Skapa fält för attribut
        field_defn = ogr.FieldDefn("depth_avg", ogr.OFTReal)
        out_layer.CreateField(field_defn)
        field_defn = ogr.FieldDefn("depth_max", ogr.OFTReal)
        out_layer.CreateField(field_defn)
        
        # Polygonisera översvämningsraster
        gdal.Polygonize(flood_band, None, out_layer, 0, [], callback=None)
        
        # Uppdatera djupvärden från depth_array
        depth_ds = gdal.Open(flood_depth_raster)
        depth_band = depth_ds.GetRasterBand(1)
        
        # Stäng datasets
        flood_ds = None
        out_ds = None
        dem_ds = None
        depth_ds = None
        
        # Ta bort temporära raster
        os.remove(temp_flood_raster)
        
        # Ladda vektorlager i QGIS
        flood_layer = QgsVectorLayer(output_path, f"Översvämning {water_level}m", "ogr")
        
        # Beräkna statistik per polygon
        with open(flood_depth_raster, 'rb') as f:
            provider = flood_layer.dataProvider()
            request = QgsFeatureRequest()
            
            for feature in provider.getFeatures(request):
                geom = feature.geometry()
                if geom.isEmpty() or geom.area() < 0.0001:  # Filter out tiny polygons
                    continue
                
                # Hämta statistik för detta område från depth_raster
                stats = depth_band.GetStatistics(True, True)
                
                # Sätt attributvärden
                attrs = {
                    provider.fieldNameIndex('depth_avg'): stats[2],  # mean
                    provider.fieldNameIndex('depth_max'): stats[1]   # max
                }
                provider.changeAttributeValues({feature.id(): attrs})
        
        # Lägg till i projekt
        QgsProject.instance().addMapLayer(flood_layer)
        
        return flood_layer
        
    except Exception as e:
        raise Exception(f"Fel vid översvämningsberäkning: {str(e)}")

def calculate_erosion(iface, dem_path, flood_layer, soil_path, output_folder):
    """Beräkna erosionsrisk baserat på översvämning och jordart
    
    :param iface: QGIS-gränssnitt
    :type iface: QgsInterface
    
    :param dem_path: Sökväg till DEM-raster
    :type dem_path: str
    
    :param flood_layer: Översvämningslager
    :type flood_layer: QgsVectorLayer
    
    :param soil_path: Sökväg till jordartslager
    :type soil_path: str
    
    :param output_folder: Mapp för utdata
    :type output_folder: str
    
    :returns: Erosionsrisklager
    :rtype: QgsVectorLayer
    """
    try:
        # Skapa output sökväg
        output_path = os.path.join(output_folder, "erosionsrisk.shp")
        
        # Läs in jordartslager
        soil_layer = QgsVectorLayer(soil_path, "Jordarter", "ogr")
        if not soil_layer.isValid():
            raise Exception("Kunde inte läsa in jordartslager")
            
        # Öppna DEM för lutningsberäkning
        dem_ds = gdal.Open(dem_path)
        if not dem_ds:
            raise Exception("Kunde inte öppna DEM-fil")
        
        # Skapa temporär lutningsraster
        slope_path = os.path.join(output_folder, "slope.tif")
        
        # Beräkna lutning med GDAL
        gdal.DEMProcessing(slope_path, dem_path, 'slope')
        
        # Ladda lutningsraster
        slope_layer = QgsRasterLayer(slope_path, "Lutning")
        if not slope_layer.isValid():
            raise Exception("Kunde inte beräkna lutning från DEM")
            
        # Skapa erosionsrisklager
        fields = QgsFields()
        fields.append(QgsField("risk", QVariant.Double))
        fields.append(QgsField("soil_type", QVariant.String))
        fields.append(QgsField("slope", QVariant.Double))
        fields.append(QgsField("depth", QVariant.Double))
        
        writer = QgsVectorFileWriter(output_path, "UTF-8", fields, QgsWkbTypes.Polygon, 
                                    soil_layer.crs(), "ESRI Shapefile")
                                    
        if writer.hasError() != QgsVectorFileWriter.NoError:
            raise Exception(f"Kunde inte skapa erosionsrisklager: {writer.errorMessage()}")
            
        # Överlappa översvämningsområden med jordartslager
        flood_features = flood_layer.getFeatures()
        soil_features = soil_layer.getFeatures()
        
        # Iterera genom översvämningsområden
        for flood_feat in flood_features:
            flood_geom = flood_feat.geometry()
            
            # Iterera genom jordartspolygoner
            for soil_feat in soil_features:
                soil_geom = soil_feat.geometry()
                
                # Om de överlappar, skapa en riskerosionspolygon
                if flood_geom.overlaps(soil_geom):
                    # Skapa överlappande område
                    intersection = flood_geom.intersection(soil_geom)
                    
                    # Skapa ny feature
                    feat = QgsFeature(fields)
                    feat.setGeometry(intersection)
                    
                    # Hämta attribut för beräkning
                    soil_type = soil_feat["JORDART"] if "JORDART" in soil_feat.fields().names() else "Unknown"
                    depth = flood_feat["depth_avg"]
                    
                    # Beräkna genomsnittlig lutning för denna polygon
                    slope = 5.0  # Default värde om vi inte kan beräkna från raster
                    
                    # Sätt erosionsrisk baserat på jordart, lutning och vattendjup
                    risk = calculate_erosion_risk(soil_type, slope, depth)
                    
                    # Sätt attribut
                    feat.setAttributes([risk, soil_type, slope, depth])
                    
                    # Lägg till i utfilen
                    writer.addFeature(feat)
                    
        # Städa upp
        writer = None
        
        # Lägg till i QGIS
        erosion_layer = QgsVectorLayer(output_path, "Erosionsrisk", "ogr")
        QgsProject.instance().addMapLayer(erosion_layer)
        
        return erosion_layer
        
    except Exception as e:
        raise Exception(f"Fel vid erosionsberäkning: {str(e)}")

def calculate_erosion_risk(soil_type, slope, depth):
    """Beräkna erosionsrisk baserat på jordart, lutning och vattendjup
    
    :param soil_type: Jordart
    :type soil_type: str
    
    :param slope: Lutning i grader
    :type slope: float
    
    :param depth: Vattendjup i meter
    :type depth: float
    
    :returns: Erosionsrisk (0-1)
    :rtype: float
    """
    # Erosionskoefficienter baserat på jordart
    soil_factors = {
        "SAND": 0.8,
        "MO": 0.9,
        "SILT": 1.0,
        "LERA": 0.6,
        "MORÄN": 0.5,
        "TORV": 0.4,
        "BERG": 0.1
    }
    
    # Default om jordarten inte finns i listan
    soil_factor = soil_factors.get(soil_type.upper(), 0.5)
    
    # Lutningsfaktor (ökar med ökande lutning)
    slope_factor = min(1.0, slope / 20.0)
    
    # Djupfaktor (ökar med ökande djup upp till en viss gräns)
    depth_factor = min(1.0, depth / 2.0)
    
    # Beräkna total risk (0-1)
    risk = soil_factor * slope_factor * depth_factor
    
    return risk

def calculate_flow_vectors(iface, dem_path, flood_layer, output_folder):
    """Beräkna flödesvektorer baserat på DEM och översvämning
    
    :param iface: QGIS-gränssnitt
    :type iface: QgsInterface
    
    :param dem_path: Sökväg till DEM-raster
    :type dem_path: str
    
    :param flood_layer: Översvämningslager
    :type flood_layer: QgsVectorLayer
    
    :param output_folder: Mapp för utdata
    :type output_folder: str
    
    :returns: Flödesvektorlager
    :rtype: QgsVectorLayer
    """
    try:
        # Skapa output sökväg
        output_path = os.path.join(output_folder, "flodespilar.shp")
        
        # Öppna DEM
        dem_ds = gdal.Open(dem_path)
        if not dem_ds:
            raise Exception("Kunde inte öppna DEM-fil")
            
        # Hämta information om DEM
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        band = dem_ds.GetRasterBand(1)
        
        # Läs DEM som numpy-array
        dem_array = band.ReadAsArray()
        
        # Skapa utloppsfil för flödespilar
        driver = ogr.GetDriverByName("ESRI Shapefile")
        if os.path.exists(output_path):
            driver.DeleteDataSource(output_path)
            
        out_ds = driver.CreateDataSource(output_path)
        out_layer = out_ds.CreateLayer("flow", None, ogr.wkbLineString)
        
        # Skapa fält för attribut
        field_defn = ogr.FieldDefn("direction", ogr.OFTReal)
        out_layer.CreateField(field_defn)
        field_defn = ogr.FieldDefn("speed", ogr.OFTReal)
        out_layer.CreateField(field_defn)
        
        # Beräkna flödesriktning
        # Först beräkna aspect (riktning för största lutning)
        aspect_path = os.path.join(output_folder, "aspect.tif")
        gdal.DEMProcessing(aspect_path, dem_path, 'aspect')
        
        # Ladda aspect-raster
        aspect_ds = gdal.Open(aspect_path)
        aspect_band = aspect_ds.GetRasterBand(1)
        aspect_array = aspect_band.ReadAsArray()
        
        # Hämta översvämningspolygon
        flood_features = flood_layer.getFeatures()
        flood_geom = None
        for feat in flood_features:
            if flood_geom is None:
                flood_geom = feat.geometry()
            else:
                flood_geom = flood_geom.combine(feat.geometry())
        
        # Skapa flödespilar för översvämningsområdet
        # Dela upp området i ett rutnät
        grid_size = 50  # meter mellan flödespilar
        
        # Konvertera grid_size till pixlar
        grid_px = int(grid_size / geotransform[1])
        
        for y in range(0, dem_array.shape[0], grid_px):
            for x in range(0, dem_array.shape[1], grid_px):
                # Konvertera pixelkoordinat till världskoordinat
                world_x = geotransform[0] + x * geotransform[1]
                world_y = geotransform[3] + y * geotransform[5]
                
                # Kontrollera om punkten är inom översvämningsområdet
                point = QgsPointXY(world_x, world_y)
                if flood_geom and flood_geom.contains(point):
                    # Hämta flödesriktning från aspect
                    if 0 <= y < aspect_array.shape[0] and 0 <= x < aspect_array.shape[1]:
                        direction = aspect_array[y, x]
                        
                        # Beräkna hastighet baserat på lutning och djup
                        # Här skulle vi använda mer avancerade hydrauliska beräkningar
                        speed = 1.0  # Default hastighetsvärde
                        
                        # Skapa flödespil
                        # Beräkna slutpunkt baserat på riktning, 20m lång pil
                        length = 20  # meter
                        # Konvertera från grader till radianer och justera för att 0=nord, 90=öst, etc.
                        angle_rad = math.radians((450 - direction) % 360)
                        end_x = world_x + length * math.sin(angle_rad)
                        end_y = world_y + length * math.cos(angle_rad)
                        
                        # Skapa linje
                        line = ogr.Geometry(ogr.wkbLineString)
                        line.AddPoint(world_x, world_y)
                        line.AddPoint(end_x, end_y)
                        
                        # Skapa feature
                        feature = ogr.Feature(out_layer.GetLayerDefn())
                        feature.SetGeometry(line)
                        feature.SetField("direction", direction)
                        feature.SetField("speed", speed)
                        
                        # Lägg till feature
                        out_layer.CreateFeature(feature)
                        feature = None
        
        # Städa upp
        out_ds = None
        dem_ds = None
        aspect_ds = None
        
        # Ta bort temporära filer
        os.remove(aspect_path)
        
        # Ladda lager i QGIS
        flow_layer = QgsVectorLayer(output_path, "Flödespilar", "ogr")
        QgsProject.instance().addMapLayer(flow_layer)
        
        return flow_layer
        
    except Exception as e:
        raise Exception(f"Fel vid flödesberäkning: {str(e)}")

def calculate_streamlines(iface, dem_path, flood_layer, output_folder):
    """Beräkna streamlines baserat på DEM och översvämning
    
    :param iface: QGIS-gränssnitt
    :type iface: QgsInterface
    
    :param dem_path: Sökväg till DEM-raster
    :type dem_path: str
    
    :param flood_layer: Översvämningslager
    :type flood_layer: QgsVectorLayer
    
    :param output_folder: Mapp för utdata
    :type output_folder: str
    
    :returns: Streamline-lager
    :rtype: QgsVectorLayer
    """
    try:
        # Skapa output sökväg
        output_path = os.path.join(output_folder, "streamlines.shp")
        
        # Beräkna flödesriktning
        flow_dir_path = os.path.join(output_folder, "flowdir.tif")
        gdal.DEMProcessing(flow_dir_path, dem_path, 'aspect')
        
        # Skapa utloppsfil för streamlines
        driver = ogr.GetDriverByName("ESRI Shapefile")
        if os.path.exists(output_path):
            driver.DeleteDataSource(output_path)
            
        out_ds = driver.CreateDataSource(output_path)
        out_layer = out_ds.CreateLayer("streamlines", None, ogr.wkbLineString)
        
        # Skapa fält för attribut
        field_defn = ogr.FieldDefn("flow_acc", ogr.OFTReal)
        out_layer.CreateField(field_defn)
        
        # För enkelhets skull, skapa några streamlines manuellt
        # I en verklig implementation skulle vi använda en D8-flödesalgorithm
        
        # Hämta översvämningspolygon för att begränsa streamlines
        flood_features = flood_layer.getFeatures()
        flood_geom = None
        for feat in flood_features:
            if flood_geom is None:
                flood_geom = feat.geometry()
            else:
                flood_geom = flood_geom.combine(feat.geometry())
            
        # Skapa startpunkter längs kanten av översvämningsområdet
        if flood_geom:
            boundary = flood_geom.boundary()
            
            # Dela upp kanten i ett antal punkter
            num_points = 10
            step = boundary.length() / num_points
            
            for i in range(num_points):
                # Hitta punkt på kanten
                distance = i * step
                point = boundary.interpolate(distance).asPoint()
                
                # Skapa streamline från denna punkt
                create_streamline(point, flood_geom, flow_dir_path, out_layer)
        
        # Städa upp
        out_ds = None
        
        # Ladda lager i QGIS
        streamline_layer = QgsVectorLayer(output_path, "Streamlines", "ogr")
        QgsProject.instance().addMapLayer(streamline_layer)
        
        return streamline_layer
        
    except Exception as e:
        raise Exception(f"Fel vid streamline-beräkning: {str(e)}")

def create_streamline(start_point, flood_geom, flow_dir_path, out_layer):
    """Skapa en streamline från en startpunkt
    
    :param start_point: Startpunkt för streamline
    :type start_point: QgsPointXY
    
    :param flood_geom: Geometri för översvämningsområde
    :type flood_geom: QgsGeometry
    
    :param flow_dir_path: Sökväg till flödesriktningsraster
    :type flow_dir_path: str
    
    :param out_layer: Utloppslager
    :type out_layer: ogr.Layer
    """
    try:
        # Öppna flödesriktning
        flow_ds = gdal.Open(flow_dir_path)
        flow_band = flow_ds.GetRasterBand(1)
        flow_array = flow_band.ReadAsArray()
        geotransform = flow_ds.GetGeoTransform()
        
        # Skapa linje
        line = ogr.Geometry(ogr.wkbLineString)
        line.AddPoint(start_point.x(), start_point.y())
        
        # Följ flödesriktningen
        max_steps = 100
        current_point = start_point
        
        for step in range(max_steps):
            # Konvertera punkt till pixelkoordinat
            pixel_x = int((current_point.x() - geotransform[0]) / geotransform[1])
            pixel_y = int((current_point.y() - geotransform[3]) / geotransform[5])
            
            # Kontrollera om utanför rastret
            if (pixel_x < 0 or pixel_x >= flow_array.shape[1] or
                pixel_y < 0 or pixel_y >= flow_array.shape[0]):
                break
                
            # Hämta flödesriktning
            direction = flow_array[pixel_y, pixel_x]
            
            # Beräkna nästa punkt
            step_length = 10  # meter per steg
            angle_rad = math.radians((450 - direction) % 360)
            next_x = current_point.x() + step_length * math.sin(angle_rad)
            next_y = current_point.y() + step_length * math.cos(angle_rad)
            
            # Skapa ny punkt
            next_point = QgsPointXY(next_x, next_y)
            
            # Kontrollera om fortfarande inom översvämningsområdet
            if not flood_geom.contains(next_point):
                break
                
            # Lägg till punkt till linjen
            line.AddPoint(next_x, next_y)
            
            # Uppdatera nuvarande punkt
            current_point = next_point
            
        # Skapa feature
        feature = ogr.Feature(out_layer.GetLayerDefn())
        feature.SetGeometry(line)
        feature.SetField("flow_acc", line.Length())  # Använd linjelängd som proxy för flödesackumulering
        
        # Lägg till feature
        out_layer.CreateFeature(feature)
        feature = None
        
        # Städa upp
        flow_ds = None
        
    except Exception as e:
        print(f"Fel vid skapande av streamline: {str(e)}")
